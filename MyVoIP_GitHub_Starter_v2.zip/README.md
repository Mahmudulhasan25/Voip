# My VoIP

Android starter project for the planned SIP calling app.

## Current starter features
- Reads phone contacts after runtime permission
- Contact list and name/number search
- GitHub Actions workflow to build a debug APK

## Important
This is the first project scaffold, not a finished VoIP client. The Select button is currently a placeholder. SIP registration/calling, call controls, call history, recording, app-managed contacts, and Google Drive backup still need implementation and testing with the SIP provider.

## Build on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this project (keep folders).
3. Open **Actions** and run **Build My VoIP APK** (or push to `main`).
4. Download the `MyVoIP-debug-apk` artifact from the completed workflow.

Never commit your SIP password or other credentials to a public repository.
