package com.mahmudul.myvoip

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

data class PhoneContact(val name: String, val number: String)

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private val contacts = mutableListOf<PhoneContact>()
    private val requestContacts = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            == PackageManager.PERMISSION_GRANTED) loadContacts()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), requestContacts)
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 12)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "My VoIP"
            textSize = 26f
            setTextColor(0xFF14213D.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "Contacts"
            textSize = 17f
            setPadding(0, 8, 0, 12)
        }
        search = EditText(this).apply {
            hint = "Search name or phone number"
            singleLine = true
            textSize = 16f
            setPadding(16, 10, 16, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        page.addView(title)
        page.addView(subtitle)
        page.addView(search, LinearLayout.LayoutParams(-1, -2))
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = renderContacts()
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadContacts() {
        contacts.clear()
        val seen = mutableSetOf<String>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val cursor: Cursor? = contentResolver.query(uri, projection, null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")
        cursor?.use {
            val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameIndex) ?: "Unknown"
                val number = it.getString(numberIndex) ?: continue
                val key = "$name|$number"
                if (seen.add(key)) contacts.add(PhoneContact(name, number))
            }
        }
        renderContacts()
    }

    private fun renderContacts() {
        list.removeAllViews()
        val query = search.text.toString().trim().lowercase(Locale.getDefault())
        val filtered = contacts.filter {
            it.name.lowercase(Locale.getDefault()).contains(query) ||
            it.number.lowercase(Locale.getDefault()).contains(query)
        }
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (contacts.isEmpty()) "No contacts found. Allow Contacts permission to view phone contacts."
                       else "No matching contacts."
                textSize = 15f
                setPadding(8, 24, 8, 24)
            })
            return
        }
        filtered.forEach { contact ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(TextView(this).apply {
                text = contact.name
                textSize = 16f
                setTextColor(0xFF14213D.toInt())
            })
            details.addView(TextView(this).apply {
                text = contact.number
                textSize = 14f
                setTextColor(0xFF667085.toInt())
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Select"
                setOnClickListener {
                    Toast.makeText(this@MainActivity,
                        "Selected ${contact.name}. SIP calling will be connected in the next development stage.",
                        Toast.LENGTH_LONG).show()
                }
            })
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = 8
            list.addView(row, params)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestContacts && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) loadContacts()
        else Toast.makeText(this, "Contacts permission is needed to show your phone contacts.", Toast.LENGTH_LONG).show()
    }
}
